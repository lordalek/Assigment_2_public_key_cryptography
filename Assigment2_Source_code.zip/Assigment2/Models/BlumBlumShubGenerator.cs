﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Assigment2.longerfaces;

namespace Assigment2.Models
{
    class BlumBlumShubGenerator :IBlumBlumShubGenerator
    {
        public ReallyBigNumber GeneratePseudoRandomNumber(long seed)
        {
            throw new NotImplementedException();
        }
    }
}
